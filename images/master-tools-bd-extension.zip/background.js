// Master Tools BD Extension - Background Script
// This script handles the main functionality of the extension

// API Base URL - Constant
// ✅ FIXED: Use production URL for Chrome Web Store submission
// For production, use: 'https://mastertoolsbd.com'
// For local testing, change to: 'http://localhost:5000'
const API_BASE_URL = 'https://api.mastertoolsbd.com'; // Production URL
// const API_BASE_URL = 'http://localhost:5000'; // Uncomment for local development

// Store active slots for heartbeat (multiple slots support)
// Array of { slotId, token, domain, platformId, retryCount, lastChecked }
// domain: Cookie model থেকে exact domain string (cookie clearing এর জন্য)
// platformId: Platform ID (future use)
// lastChecked: Last status check timestamp
// retryCount: Number of consecutive 404 errors for this slot
let activeSlots = [];

// Periodic status check interval (30 seconds)
const STATUS_CHECK_INTERVAL = 30000; // 30 seconds = 30000 milliseconds
let statusCheckIntervalId = null; // Interval ID (stop করার জন্য)

// IMPROVEMENT: Validate activeSlots array structure
function validateActiveSlots(slots) {
    if (!Array.isArray(slots)) {
        return [];
    }
    
    return slots.filter(slot => {
        // Validate required fields
        if (!slot || typeof slot !== 'object') {
            return false;
        }
        if (!slot.slotId || typeof slot.slotId !== 'string') {
            return false;
        }
        if (!slot.token || typeof slot.token !== 'string') {
            return false;
        }
        // Optional fields with defaults
        return true;
    }).map(slot => ({
        slotId: slot.slotId,
        token: slot.token,
        domain: slot.domain || null,
        platformId: slot.platformId || null,
        retryCount: typeof slot.retryCount === 'number' ? slot.retryCount : 0,
        lastChecked: slot.lastChecked || null
    }));
}

// IMPROVEMENT: Clean up orphaned alarms
async function cleanupOrphanedAlarms() {
    try {
        const alarms = await chrome.alarms.getAll();
        const heartbeatAlarms = alarms.filter(a => a.name.startsWith('heartbeat-'));
        
        if (heartbeatAlarms.length === 0) {
            return;
        }
        
        // Get all slot IDs from activeSlots
        const activeSlotIds = activeSlots.map(s => s.slotId);
        
        // Find orphaned alarms (alarms without corresponding slots)
        const orphanedAlarms = heartbeatAlarms.filter(alarm => {
            const slotId = alarm.name.replace('heartbeat-', '');
            return !activeSlotIds.includes(slotId);
        });
        
        if (orphanedAlarms.length > 0) {
            // console.log(`🧹 Cleaning up ${orphanedAlarms.length} orphaned alarm(s)`);
            for (const alarm of orphanedAlarms) {
                await chrome.alarms.clear(alarm.name);
                // console.log(`   Cleared orphaned alarm: ${alarm.name}`);
            }
        }
    } catch (error) {
        // console.error('❌ Error cleaning up orphaned alarms:', error);
    }
}

// Load heartbeat state from storage when service worker starts
async function loadHeartbeatState() {
    try {
        // Try new format first (array of slots)
        const result = await chrome.storage.local.get(['activeSlots', 'heartbeatSlotId', 'heartbeatToken']);
        
        // Migration: Convert old format to new format
        if (result.heartbeatSlotId && result.heartbeatToken && (!result.activeSlots || result.activeSlots.length === 0)) {
            // console.log('🔄 Migrating old heartbeat storage format to new format');
            activeSlots = [{
                slotId: result.heartbeatSlotId,
                token: result.heartbeatToken,
                domain: null, // Will be fetched from server
                platformId: null, // Will be fetched from server
                retryCount: 0,
                lastChecked: null
            }];
            // Save in new format and clear old format
            await chrome.storage.local.set({ activeSlots: activeSlots });
            await chrome.storage.local.remove(['heartbeatSlotId', 'heartbeatToken']);
        } else if (result.activeSlots) {
            // IMPROVEMENT: Validate activeSlots structure
            const originalLength = Array.isArray(result.activeSlots) ? result.activeSlots.length : 0;
            activeSlots = validateActiveSlots(result.activeSlots);
            
            // If validation removed slots, save cleaned version
            if (originalLength !== activeSlots.length) {
                // console.warn(`⚠️ Removed ${originalLength - activeSlots.length} invalid slot(s) from storage`);
                await chrome.storage.local.set({ activeSlots: activeSlots });
            }
        } else {
            // No active slots
            activeSlots = [];
        }
        
        if (activeSlots.length > 0) {
            // console.log(`🔄 Restoring ${activeSlots.length} heartbeat slot(s) from storage`);
            
            // IMPROVEMENT: Clean up orphaned alarms first
            await cleanupOrphanedAlarms();
            
            // Restore alarms for each slot
            const alarms = await chrome.alarms.getAll();
            const existingAlarmNames = alarms.map(a => a.name);
            
            const validSlots = [];
            for (const slot of activeSlots) {
                if (!slot.slotId || !slot.token) {
                    // console.warn(`⚠️ Skipping invalid slot:`, slot);
                    continue;
                }
                
                validSlots.push(slot);
                const alarmName = `heartbeat-${slot.slotId}`;
                
                if (!existingAlarmNames.includes(alarmName)) {
                    // console.log(`   Creating heartbeat alarm for slot: ${slot.slotId}`);
                    chrome.alarms.create(alarmName, {
                        delayInMinutes: 1,
                        periodInMinutes: 1
                    }).catch((error) => {
                        // console.error(`❌ Error creating alarm for slot ${slot.slotId}:`, error);
                        // Remove slot if alarm creation fails
                        validSlots.splice(validSlots.indexOf(slot), 1);
                    });
                    // Send immediate heartbeat for this slot
                    setTimeout(() => {
                        sendHeartbeat(slot.slotId);
                    }, 1000);
                } else {
                    // console.log(`   Heartbeat alarm already exists for slot: ${slot.slotId}`);
                }
            }
            
            // Update activeSlots with valid slots only
            if (validSlots.length !== activeSlots.length) {
                activeSlots = validSlots;
                await saveHeartbeatState();
            }
            
            // Clean up old 'heartbeat' alarm if it exists (migration)
            if (existingAlarmNames.includes('heartbeat')) {
                // console.log('   Cleaning up old heartbeat alarm');
                chrome.alarms.clear('heartbeat');
            }
            
            // Start periodic status check if slots exist
            if (activeSlots.length > 0) {
                startPeriodicStatusCheck();
            }
        } else {
            // IMPROVEMENT: Clean up any orphaned alarms even if no active slots
            await cleanupOrphanedAlarms();
        }
    } catch (error) {
        // console.error('❌ Error loading heartbeat state:', error);
        activeSlots = [];
        // IMPROVEMENT: Try to clean up alarms even on error
        try {
            await cleanupOrphanedAlarms();
        } catch (cleanupError) {
            // console.error('❌ Error cleaning up alarms after load error:', cleanupError);
        }
    }
}

// Save heartbeat state to storage (persistent across service worker restarts)
async function saveHeartbeatState() {
    try {
        await chrome.storage.local.set({
            activeSlots: activeSlots
        });
        // console.log(`💾 Heartbeat state saved to storage (${activeSlots.length} slot(s))`);
    } catch (error) {
        // console.error('❌ Error saving heartbeat state:', error);
    }
}

// Clear heartbeat state from storage
async function clearHeartbeatState() {
    try {
        await chrome.storage.local.remove(['activeSlots', 'heartbeatSlotId', 'heartbeatToken']);
        // console.log('🗑️ Heartbeat state cleared from storage');
    } catch (error) {
        // console.error('❌ Error clearing heartbeat state:', error);
    }
}

// Clear cookies for a domain (exact domain from Cookie model)
// Domain null/empty হলে skip করবে কিন্তু error throw করবে না
async function clearCookiesForDomain(domain) {
    // Step 1: Domain validate করো
    if (!domain || typeof domain !== 'string' || domain.trim() === '') {
        // console.warn('⚠️ Domain is null or empty, skipping cookie clear');
        return { cleared: 0, skipped: true };
    }
    
    try {
        // Step 2: Domain normalize করো (exact domain string use করো)
        let normalizedDomain = domain.trim();
        
        // Remove protocol (http://, https://)
        if (normalizedDomain.startsWith('http://') || normalizedDomain.startsWith('https://')) {
            try {
                // URL object use করে hostname extract করো
                const url = new URL(normalizedDomain);
                normalizedDomain = url.hostname;
            } catch (e) {
                // URL parsing fail হলে manually extract করো
                normalizedDomain = normalizedDomain.replace(/^https?:\/\//, '').split('/')[0].split('?')[0];
            }
        }
        
        // Remove leading dot (cookie domain format: .example.com → example.com)
        normalizedDomain = normalizedDomain.replace(/^\./, '');
        
        // Remove port (example.com:8080 → example.com)
        normalizedDomain = normalizedDomain.split(':')[0];
        
        // Final validation
        if (!normalizedDomain || normalizedDomain.trim() === '') {
            // console.warn('⚠️ Invalid domain after normalization, skipping cookie clear');
            return { cleared: 0, skipped: true };
        }
        
        // console.log(`🍪 Clearing cookies for domain: ${normalizedDomain}`);
        
        // Step 3: Get all cookies for the exact domain
        // Chrome cookies API-তে domain format: "example.com" বা ".example.com"
        const cookies1 = await chrome.cookies.getAll({ domain: normalizedDomain });
        const cookies2 = await chrome.cookies.getAll({ domain: `.${normalizedDomain}` });
        
        // Step 4: Combine and deduplicate cookies
        const allCookies = [...cookies1, ...cookies2];
        const cookieMap = new Map(); // Deduplicate by name+domain
        allCookies.forEach(cookie => {
            const key = `${cookie.name}_${cookie.domain}`;
            if (!cookieMap.has(key)) {
                cookieMap.set(key, cookie);
            }
        });
        const uniqueCookies = Array.from(cookieMap.values());
        
        // Step 5: Clear each cookie
        let clearedCount = 0;
        let errorCount = 0;
        
        for (const cookie of uniqueCookies) {
            try {
                // Construct URL for cookie removal
                // chrome.cookies.remove() requires full URL
                const protocol = cookie.secure ? 'https' : 'http';
                const domainPart = cookie.domain.startsWith('.') 
                    ? cookie.domain.substring(1) 
                    : cookie.domain;
                const url = `${protocol}://${domainPart}${cookie.path || '/'}`;
                
                // Remove cookie
                await chrome.cookies.remove({
                    url: url,
                    name: cookie.name
                });
                clearedCount++;
            } catch (error) {
                errorCount++;
                // console.warn(`⚠️ Failed to clear cookie ${cookie.name} for ${cookie.domain}:`, error.message);
            }
        }
        
        // Step 6: Log results
        if (clearedCount > 0) {
            // console.log(`✅ Cleared ${clearedCount} cookie(s) for domain: ${normalizedDomain}`);
        } else if (uniqueCookies.length === 0) {
            // console.log(`ℹ️ No cookies found for domain: ${normalizedDomain}`);
        }
        
        if (errorCount > 0) {
            // console.warn(`⚠️ Failed to clear ${errorCount} cookie(s) for domain: ${normalizedDomain}`);
        }
        
        // Return result
        return { 
            cleared: clearedCount, 
            skipped: false, 
            total: uniqueCookies.length,
            errors: errorCount
        };
    } catch (error) {
        // Any unexpected error
        // console.error(`❌ Error clearing cookies for domain ${domain}:`, error);
        return { cleared: 0, skipped: false, error: error.message };
    }
}

// Check slot status on server
// Returns: { isActive: boolean, domain: string|null, error: string|null }
async function checkSlotStatus(slotId, token) {
    // Step 1: Validate parameters
    if (!slotId || !token) {
        // console.error('❌ Cannot check slot status: Missing slotId or token');
        return { isActive: false, error: 'Missing parameters', domain: null };
    }
    
    // Step 2: Build API URL
    const url = `${API_BASE_URL}/api/slots/${slotId}/status`;
    
    try {
        // Step 3: Make API request
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            mode: 'cors',
            credentials: 'omit'
        });
        
        // Step 4: Handle response
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            // console.error(`❌ Check slot status failed for slot ${slotId}:`, {
            //     status: response.status,
            //     error: errorData
            // });
            
            // 404 = Slot not found, 401 = Unauthorized
            // Both mean user is definitely not active
            if (response.status === 404 || response.status === 401) {
                return { 
                    isActive: false, 
                    error: errorData.error || 'Slot not found or unauthorized', 
                    domain: null 
                };
            }
            
            // Other errors
            return { 
                isActive: false, 
                error: errorData.error || 'Unknown error', 
                domain: null 
            };
        }
        
        // Step 5: Parse and return data
        const data = await response.json();
        return data; // { isActive, domain, slotId, platformId, ... }
    } catch (error) {
        // Network errors, etc.
        // console.error(`❌ Error checking slot status for slot ${slotId}:`, error);
        // Don't fail completely - will retry next time
        return { isActive: false, error: error.message, domain: null };
    }
}

// Handle instant slot release (from socket events via website)
// This function is called when admin resets/deletes/updates slot
// Active users: Cookies cleared immediately
// Inactive users: Error handled gracefully (no retry, will be handled by browser startup/periodic check)
async function handleInstantSlotRelease(slotId, platformId, planId, reason) {
    // console.log(`🔔 Instant slot release detected: ${slotId} (reason: ${reason})`);
    
    // Find slot in activeSlots
    const slot = activeSlots.find(s => s.slotId === slotId);
    
    if (!slot) {
        // Slot not found in activeSlots (inactive user - browser closed)
        // NO RETRY - Will be handled by browser startup check or periodic check (existing system)
        // console.log(`ℹ️ Slot ${slotId} not found in active slots (inactive user - will be handled on browser open or periodic check)`);
        return; // Early return - no retry
    }
    
    // Slot found - user is active (browser open)
    // Check slot status to confirm and get domain
    try {
        const status = await checkSlotStatus(slot.slotId, slot.token);
        
        // Handle different scenarios
        if (!status.isActive) {
            // Slot released - clear cookies immediately
            // console.log(`🔄 Slot ${slotId} confirmed released, clearing cookies immediately...`);
            
            // Get domain to clear (prefer stored domain, fallback to status domain)
            const domainToClear = slot.domain || status.domain;
            
            if (domainToClear && domainToClear.trim() !== '') {
                const clearResult = await clearCookiesForDomain(domainToClear);
                if (clearResult.cleared > 0) {
                    // console.log(`✅ Cleared ${clearResult.cleared} cookie(s) for slot ${slotId} (instant)`);
                } else if (!clearResult.skipped) {
                    // console.log(`ℹ️ No cookies cleared for slot ${slotId} (domain: ${domainToClear})`);
                }
            } else {
                // console.warn(`⚠️ Domain not available for slot ${slotId}, skipping cookie clear`);
            }
            
            // Stop heartbeat for this slot
            stopHeartbeat(slot.slotId);
        } else {
            // Slot still active (shouldn't happen if event is correct, but handle gracefully)
            // console.log(`⚠️ Slot ${slotId} still active despite release event (may be timing issue)`);
        }
    } catch (error) {
        // Handle errors gracefully - NO RETRY
        // Network errors, offline, etc. - NO RETRY
        // Will be handled by periodic check (30 seconds) or browser startup check (existing system)
        // console.error(`❌ Error checking slot ${slotId} for instant release:`, error.message || error);
        // console.log(`ℹ️ NO RETRY - Will be handled by periodic check (30 seconds) or browser startup check (existing system)`);
        // Don't remove slot or stop heartbeat - let existing periodic check handle it
        // NO RETRY - Function returns here
    }
}

// Check all active slots and clear cookies if released
// এই function periodic check এবং startup check-এ call হবে
async function checkAllActiveSlots() {
    // Step 1: Load slots from storage if not in memory
    // (Service worker restart হলে memory clear হয়ে যায়)
    if (activeSlots.length === 0) {
        try {
            const result = await chrome.storage.local.get(['activeSlots']);
            if (result.activeSlots && Array.isArray(result.activeSlots) && result.activeSlots.length > 0) {
                activeSlots = result.activeSlots;
            } else {
                // No active slots, stop checking
                stopPeriodicStatusCheck();
                return;
            }
        } catch (error) {
            // console.error('❌ Error loading slots from storage:', error);
            return;
        }
    }
    
    // Step 2: If no active slots, stop checking
    if (activeSlots.length === 0) {
        stopPeriodicStatusCheck();
        return;
    }
    
    // console.log(`🔍 Checking ${activeSlots.length} active slot(s) for release status...`);
    
    // Step 3: Check each slot
    const slotsToRemove = []; // Released slots (remove করার জন্য)
    const now = Date.now(); // Current timestamp
    
    for (const slot of activeSlots) {
        // Skip invalid slots
        if (!slot.slotId || !slot.token) {
            // console.warn(`⚠️ Skipping invalid slot:`, slot);
            continue;
        }
        
        try {
            // Step 4: Check slot status on server
            const status = await checkSlotStatus(slot.slotId, slot.token);
            
            // Step 5: Update slot info (lastChecked, domain)
            const slotIndex = activeSlots.findIndex(s => s.slotId === slot.slotId);
            if (slotIndex !== -1) {
                // Update lastChecked timestamp
                activeSlots[slotIndex].lastChecked = now;
                
                // Update domain if available and not already set
                // (Server থেকে domain fetch করলে store করো)
                if (status.domain && !activeSlots[slotIndex].domain) {
                    activeSlots[slotIndex].domain = status.domain;
                    // console.log(`📝 Updated domain for slot ${slot.slotId}: ${status.domain}`);
                }
            }
            
            // Step 6: If slot is released, clear cookies and stop heartbeat
            if (!status.isActive) {
                // console.log(`🔄 Slot ${slot.slotId} is released, clearing cookies...`);
                
                // Get domain to clear (prefer stored domain, fallback to status domain)
                const domainToClear = slot.domain || status.domain;
                
                // Clear cookies if domain is available
                if (domainToClear && domainToClear.trim() !== '') {
                    const clearResult = await clearCookiesForDomain(domainToClear);
                    if (clearResult.cleared > 0) {
                        // console.log(`✅ Cleared ${clearResult.cleared} cookie(s) for slot ${slot.slotId}`);
                    } else if (!clearResult.skipped) {
                        // console.log(`ℹ️ No cookies cleared for slot ${slot.slotId} (domain: ${domainToClear})`);
                    }
                } else {
                    // Domain not available - skip cookie clear but continue
                    // console.warn(`⚠️ Domain not available for slot ${slot.slotId}, skipping cookie clear (heartbeat will continue)`);
                }
                
                // Stop heartbeat for this slot
                stopHeartbeat(slot.slotId);
                slotsToRemove.push(slot.slotId);
            } else {
                // Slot is still active
                // console.log(`✅ Slot ${slot.slotId} is still active`);
            }
        } catch (error) {
            // Error checking this slot - don't remove it, will retry next time
            // console.error(`❌ Error checking slot ${slot.slotId}:`, error);
        }
    }
    
    // Step 7: Remove released slots from array
    if (slotsToRemove.length > 0) {
        activeSlots = activeSlots.filter(s => !slotsToRemove.includes(s.slotId));
        await saveHeartbeatState(); // Save updated state
        // console.log(`🗑️ Removed ${slotsToRemove.length} released slot(s)`);
        
        // If no more active slots, stop periodic check
        if (activeSlots.length === 0) {
            stopPeriodicStatusCheck();
        }
    } else {
        // No slots released, but save state (lastChecked, domain updates)
        await saveHeartbeatState();
    }
}

// Start periodic status check (every 30 seconds)
function startPeriodicStatusCheck() {
    // Step 1: Clear existing interval if any (avoid duplicates)
    if (statusCheckIntervalId !== null) {
        clearInterval(statusCheckIntervalId);
        statusCheckIntervalId = null;
    }
    
    // Step 2: Check immediately on startup (after short delay)
    setTimeout(() => {
        checkAllActiveSlots();
    }, 2000); // 2 seconds wait (storage ready হওয়ার জন্য)
    
    // Step 3: Set up interval for periodic checks
    statusCheckIntervalId = setInterval(async () => {
        // Check if there are any active slots
        if (activeSlots.length === 0) {
            stopPeriodicStatusCheck(); // No slots, stop checking
            return;
        }
        // Check all slots
        await checkAllActiveSlots();
    }, STATUS_CHECK_INTERVAL); // 30 seconds
    
    // console.log('🔄 Started periodic status check (30 seconds interval)');
}

// Stop periodic status check
function stopPeriodicStatusCheck() {
    if (statusCheckIntervalId !== null) {
        clearInterval(statusCheckIntervalId);
        statusCheckIntervalId = null;
        // console.log('🛑 Stopped periodic status check');
    }
}

// Heartbeat function - Server কে "I Am Alive" message পাঠাবে
// slotId: Specific slot ID to send heartbeat for
async function sendHeartbeat(slotId) {
    if (!slotId) {
        // console.error('❌ Cannot send heartbeat: Missing slotId parameter');
        return;
    }
    
    // IMPROVEMENT: Check network status before sending heartbeat
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
        // console.warn(`⚠️ Network offline, skipping heartbeat for slot ${slotId}`);
        // Don't increment retry count for offline - it's not a real error
        return;
    }
    
    // Find slot in memory
    let slot = activeSlots.find(s => s.slotId === slotId);
    
    // If not found in memory, try loading from storage (service worker restarted)
    if (!slot) {
        try {
            const result = await chrome.storage.local.get(['activeSlots']);
            if (result.activeSlots && Array.isArray(result.activeSlots)) {
                activeSlots = result.activeSlots;
                slot = activeSlots.find(s => s.slotId === slotId);
            }
        } catch (error) {
            // console.error('❌ Error loading slots from storage:', error);
        }
    }
    
    if (!slot || !slot.token) {
        // console.warn(`⚠️ Cannot send heartbeat for slot ${slotId}: Slot not found or missing token`);
        // Clear alarm for this slot if it's no longer valid
        chrome.alarms.clear(`heartbeat-${slotId}`);
        // Remove from array if exists
        activeSlots = activeSlots.filter(s => s.slotId !== slotId);
        saveHeartbeatState();
        return;
    }
    
    const url = `${API_BASE_URL}/api/slots/${slotId}/heartbeat`;
    
    try {
        // console.log(`📡 Sending heartbeat to: ${url}`);
        // console.log(`   Slot ID: ${slotId}`);
        // console.log(`   Network status: ${typeof navigator !== 'undefined' && navigator.onLine ? 'online' : 'unknown'}`);
        
        const response = await fetch(url, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${slot.token}`,
                'Content-Type': 'application/json'
            },
            mode: 'cors',
            credentials: 'omit'
        });
        
        // console.log(`   Response status: ${response.status}`);
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            // console.error(`❌ Heartbeat failed for slot ${slotId}:`, {
            //     status: response.status,
            //     statusText: response.statusText,
            //     error: errorData,
            //     timestamp: new Date().toISOString()
            // });
            
            // Handle different error statuses
            if (response.status === 400 || response.status === 401) {
                // 400: User not using slot, 401: Authentication failed
                // IMPORTANT: Clear cookies BEFORE stopping heartbeat (slot will be removed)
                // console.log(`🔄 Slot ${slotId} released (status: ${response.status}), clearing cookies...`);
                
                // Step 1: Get domain from stored slot data (BEFORE stopHeartbeat removes it)
                let domainToClear = slot.domain || null;
                
                // Step 2: If domain not stored, try to fetch from server (may fail for 401)
                if (!domainToClear || domainToClear.trim() === '') {
                    // console.log(`   Domain not stored, attempting to fetch from server...`);
                    try {
                        const status = await checkSlotStatus(slotId, slot.token);
                        if (status && status.domain && status.domain.trim() !== '') {
                            domainToClear = status.domain;
                            // console.log(`   ✅ Fetched domain from server: ${domainToClear}`);
                        }
                    } catch (error) {
                        // checkSlotStatus may fail (especially for 401), that's okay
                        // console.warn(`   ⚠️ Could not fetch domain from server: ${error.message}`);
                    }
                }
                
                // Step 3: Clear cookies if domain is available
                if (domainToClear && domainToClear.trim() !== '') {
                    try {
                        // console.log(`🍪 Clearing cookies for domain: ${domainToClear}`);
                        const clearResult = await clearCookiesForDomain(domainToClear);
                        if (clearResult.cleared > 0) {
                            // console.log(`✅ Cleared ${clearResult.cleared} cookie(s) for slot ${slotId}`);
                        } else if (!clearResult.skipped) {
                            // console.log(`ℹ️ No cookies found/cleared for slot ${slotId} (domain: ${domainToClear})`);
                        }
                    } catch (error) {
                        // Don't fail if cookie clearing fails - still need to stop heartbeat
                        // console.error(`❌ Error clearing cookies for slot ${slotId}:`, error.message);
                    }
                } else {
                    // console.warn(`⚠️ Domain not available for slot ${slotId}, skipping cookie clear`);
                }
                
                // Step 4: Now stop heartbeat after clearing cookies
                // console.log(`🛑 Stopping heartbeat for slot ${slotId} - ${response.status === 400 ? 'user no longer has access' : 'authentication failed'}`);
                stopHeartbeat(slotId);
            } else if (response.status === 404) {
                // 404: Slot not found - might be temporary (timing issue) or permanent (slot deleted)
                // Use retry logic: only stop after 3 consecutive 404 failures
                const slotIndex = activeSlots.findIndex(s => s.slotId === slotId);
                if (slotIndex !== -1) {
                    activeSlots[slotIndex].retryCount = (activeSlots[slotIndex].retryCount || 0) + 1;
                    const retryCount = activeSlots[slotIndex].retryCount;
                    
                    // console.warn(`⚠️ Slot ${slotId} not found (404). Retry count: ${retryCount}/3`);
                    // console.warn(`   This might be a temporary timing issue. Will retry on next alarm.`);
                    // console.warn(`   If this persists, the slot may have been deleted from the database.`);
                    
                    if (retryCount >= 3) {
                        // console.error(`❌ Slot ${slotId} not found after ${retryCount} attempts. Stopping heartbeat.`);
                        // console.error(`   Possible reasons:`);
                        // console.error(`   1. Slot was deleted from database`);
                        // console.error(`   2. Slot ID is incorrect`);
                        // console.error(`   3. Database connection issue`);
                        stopHeartbeat(slotId);
                    } else {
                        // Save updated retry count
                        saveHeartbeatState();
                    }
                }
            } else {
                // Other error statuses (500, 503, etc.) - log but don't stop heartbeat
                // console.warn(`⚠️ Heartbeat failed for slot ${slotId} with status ${response.status}. Will retry on next alarm.`);
            }
        } else {
            // Success - reset retry count
            const slotIndex = activeSlots.findIndex(s => s.slotId === slotId);
            if (slotIndex !== -1) {
                if (activeSlots[slotIndex].retryCount > 0) {
                    activeSlots[slotIndex].retryCount = 0;
                    saveHeartbeatState();
                    // console.log(`✅ Heartbeat successful for slot ${slotId}, retry count reset`);
                }
            }
            
            const data = await response.json().catch(() => ({}));
            // console.log(`✅ Heartbeat sent successfully for slot ${slotId}`, data);
        }
    } catch (error) {
        // IMPROVEMENT: Better error handling with network detection
        if (error.name === 'TypeError' && error.message.includes('Failed to fetch')) {
            // console.warn(`🌐 Network error for slot ${slotId}: ${error.message}. Will retry on next alarm.`);
            // Check if we're actually offline
            if (typeof navigator !== 'undefined' && !navigator.onLine) {
                // console.warn(`   Browser reports offline status. Heartbeat will resume when connection is restored.`);
            }
        } else {
            // More detailed error logging
            // console.error(`❌ Error sending heartbeat for slot ${slotId}:`, {
            //     error: error.message,
            //     errorType: error.name,
            //     errorStack: error.stack,
            //     url: url,
            //     slotId: slotId,
            //     hasToken: !!slot.token,
            //     timestamp: new Date().toISOString()
            // });
        }
        
        // Don't stop heartbeat on network errors - retry will happen on next alarm
        // Server will detect inactivity after 3 missed heartbeats
    }
}

// Start heartbeat - প্রতি ১ মিনিটে server কে ping করবে
// Adds a new slot to the active slots array (doesn't stop existing ones)
// domain: Cookie model থেকে exact domain string (optional)
// platformId: Platform ID (optional)
function startHeartbeat(slotId, token, domain = null, platformId = null) {
    if (!slotId || !token) {
        // console.error('❌ Cannot start heartbeat: Missing slotId or token');
        return;
    }
    
    const alarmName = `heartbeat-${slotId}`;
    
    // IMPROVEMENT: Check for existing alarm BEFORE checking activeSlots
    // This prevents duplicate alarms from being created
    chrome.alarms.get(alarmName, (existingAlarm) => {
        // Check if slot already exists in activeSlots
        const existingSlot = activeSlots.find(s => s.slotId === slotId);
        
        if (existingSlot) {
            // console.log(`⚠️ Heartbeat already active for slot ${slotId}, updating info`);
            
            // Clear existing alarm if found (cleanup)
            if (existingAlarm) {
                // console.log(`   Clearing existing alarm for slot ${slotId}`);
                chrome.alarms.clear(alarmName);
            }
            
            // Update token, domain, platformId if provided
            existingSlot.token = token;
            if (domain) existingSlot.domain = domain;
            if (platformId) existingSlot.platformId = platformId;
            saveHeartbeatState();
            
            // Recreate alarm to ensure it's active
            chrome.alarms.create(alarmName, {
                delayInMinutes: 1,
                periodInMinutes: 1
            });
            
            // console.log(`✅ Heartbeat alarm recreated for slot ${slotId}`);
            
            // Start periodic check if not already running
            if (statusCheckIntervalId === null) {
                startPeriodicStatusCheck();
            }
            return;
        }
        
        // If alarm exists but slot not in activeSlots, clean up orphaned alarm
        if (existingAlarm) {
            // console.log(`⚠️ Found orphaned alarm for slot ${slotId}, clearing...`);
            chrome.alarms.clear(alarmName);
        }
        
        // console.log(`🔄 Starting heartbeat for slot ${slotId}`);
        // console.log(`   Using API: ${API_BASE_URL}`);
        if (domain) {
            // console.log(`   Domain: ${domain}`);
        }
        // console.log(`   Active slots: ${activeSlots.length + 1}`);
        
        // Add to active slots array
        activeSlots.push({
            slotId: slotId,
            token: token,
            domain: domain || null, // Store domain if provided
            platformId: platformId || null, // Store platformId if provided
            retryCount: 0, // Initialize retry counter for 404 errors
            lastChecked: null
        });
        
        // Save to storage (persistent across service worker restarts)
        saveHeartbeatState();
        
        // Create alarm for this specific slot
        // Alarms work even when service worker is inactive!
        chrome.alarms.create(alarmName, {
            delayInMinutes: 1,        // First heartbeat after 1 minute
            periodInMinutes: 1        // Then every 1 minute
        }).then(() => {
            // console.log(`✅ Heartbeat alarm created for slot ${slotId}`);
        }).catch((error) => {
            // console.error(`❌ Error creating alarm for slot ${slotId}:`, error);
            // Remove slot from activeSlots if alarm creation fails
            activeSlots = activeSlots.filter(s => s.slotId !== slotId);
            saveHeartbeatState();
        });
        
        // Start periodic status check if not already running
        if (statusCheckIntervalId === null) {
            startPeriodicStatusCheck();
        }
        
        // Send immediate heartbeat with small delay to ensure service worker is ready
        setTimeout(() => {
            sendHeartbeat(slotId);
        }, 1000); // 1 second delay
    });
}

// Stop heartbeat
// slotId: Optional. If provided, stops heartbeat for that specific slot only.
//         If not provided, stops all heartbeats.
function stopHeartbeat(slotId = null) {
    if (slotId) {
        // Stop specific slot
        const slotIndex = activeSlots.findIndex(s => s.slotId === slotId);
        if (slotIndex !== -1) {
            // console.log(`🛑 Stopping heartbeat for slot ${slotId}`);
            // Remove from array
            activeSlots.splice(slotIndex, 1);
            // Clear alarm for this slot
            chrome.alarms.clear(`heartbeat-${slotId}`);
            // Save updated state
            saveHeartbeatState();
            
            // Stop periodic check if no more active slots
            if (activeSlots.length === 0) {
                stopPeriodicStatusCheck();
            }
        } else {
            // console.log(`⚠️ Slot ${slotId} not found in active slots`);
        }
    } else {
        // Stop all heartbeats
        // console.log(`🛑 Stopping all heartbeats (${activeSlots.length} slot(s))`);
        
        // Clear all alarms
        for (const slot of activeSlots) {
            chrome.alarms.clear(`heartbeat-${slot.slotId}`);
        }
        
        // Also clear old 'heartbeat' alarm if it exists (migration)
        chrome.alarms.clear('heartbeat');
        
        // Clear memory
        activeSlots = [];
        
        // Clear storage
        clearHeartbeatState();
        
        // Stop periodic check
        stopPeriodicStatusCheck();
    }
}

// Listen for alarm events (triggers even when service worker is inactive!)
chrome.alarms.onAlarm.addListener((alarm) => {
    // Handle new format: heartbeat-{slotId}
    if (alarm.name.startsWith('heartbeat-')) {
        const slotId = alarm.name.replace('heartbeat-', '');
        // console.log(`⏰ Heartbeat alarm triggered for slot: ${slotId}`);
        sendHeartbeat(slotId);
    }
    // Handle old format: 'heartbeat' (for migration)
    else if (alarm.name === 'heartbeat') {
        // console.log('⏰ Old heartbeat alarm triggered (migration)');
        // Try to send heartbeat for first active slot if exists
        if (activeSlots.length > 0) {
            sendHeartbeat(activeSlots[0].slotId);
        }
    }
});

// When service worker starts (browser opens), restore heartbeat
chrome.runtime.onStartup.addListener(() => {
    // console.log('🚀 Browser started - loading heartbeat state');
    loadHeartbeatState().then(() => {
        // Check all slots on startup after a short delay
        setTimeout(() => {
            checkAllActiveSlots();
        }, 3000); // 3 seconds wait (storage এবং network ready হওয়ার জন্য)
    });
});

// Listen for messages from the content script
// import { CookieEditor } from 'https://unpkg.com/cookie-editor/dist/cookie-editor.min.js';
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.type === "SET_COOKIES") {
    const { domain, cookieData } = message.payload;
    
    try {
      // console.log("Setting cookies for domain:", domain);
      const cookies = JSON.parse(cookieData);
      const cookiePromises= cookies.map(cookie => {
        // console.log(cookie.domain)
        return chrome.cookies.set({
          domain: cookie.domain || '',
          name: cookie.name || '',
          value: cookie.value || '',
          path: cookie.path || '/',
          secure: cookie.secure || null,
          httpOnly: cookie.httpOnly || null,
          expirationDate: cookie.expirationDate || null,
          storeId: cookie.storeId || (this.currentTab ? this.currentTab.cookieStoreId || '0' : '0'),
          url: domain,
        });
      });
      
      Promise.all(cookiePromises)
        .then(() => {
          // console.log("All cookies set successfully, opening domain:", domain);
          chrome.storage.local.get(['cookieCount'], function(result) {
            const count = (result.cookieCount || 0) + 1;
            chrome.storage.local.set({ cookieCount: count });
            // console.log("Cookie count incremented to:", count);
          });
          
          sendResponse({ success: true });
          return chrome.tabs.create({ url: domain });
        })
        .catch(error => {
          // console.error('Error setting cookies:', error);

          sendResponse({ success: false, error: error.message });
         return chrome.tabs.create({ url: domain });
        });
    } catch (error) {
      // console.error('Error processing cookies:', error);
      sendResponse({ success: false, error: error.message });
    }
    
    return true; // Keep the message channel open for the async response
  }
  
  // Handle the new platform access API
  if (message.type === "ACCESS") {
    const { platform, token, platformData } = message.payload;
    
    try {
      // console.log("Accessing platform:", platform);
      
      // If platformData is already provided, use it directly
      if (platformData) {
        processPlatformData(platformData, sendResponse);
      } 
      // Otherwise fetch it from the API
      else {
        fetchPlatformData(platform, token)
          .then(data => processPlatformData(data, sendResponse))
          .catch(error => {
            // console.error('Error fetching platform data:', error);
            sendResponse({ success: false, error: error.message });
          });
      }
    } catch (error) {
      // console.error('Error processing platform access:', error);
      sendResponse({ success: false, error: error.message });
    }
    
    return true; // Keep the message channel open for the async response
  }
  
  // Start heartbeat when user accesses platform
  if (message.type === "START_HEARTBEAT") {
    const { slotId, token, domain, platformId } = message.payload;
    startHeartbeat(slotId, token, domain || null, platformId || null);
    sendResponse({ success: true });
    return true;
  }
  
  // Handle instant slot release (from socket events via website)
  if (message.type === "SLOT_RELEASED" || message.type === "SLOT_DELETED") {
    const { slotId, platformId, planId, reason } = message.payload;
    
    // Handle instant slot release (no retry on error)
    handleInstantSlotRelease(slotId, platformId, planId, reason);
    
    sendResponse({ success: true });
    return true;
  }
  
  // Stop heartbeat
  if (message.type === "STOP_HEARTBEAT") {
    stopHeartbeat();
    sendResponse({ success: true });
    return true;
  }
});

// Function to fetch platform data from the API
async function fetchPlatformData(platform, token) {
  const apiUrl = `${API_BASE_URL}/api/cookies/latest?platform=${platform}`;
  
  // console.log(`Fetching platform data from: ${apiUrl}`);
  
  const response = await fetch(apiUrl, {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });
  
  if (!response.ok) {
    if (response.status === 401) {
      throw new Error('Authentication expired. Please log in again.');
    }
    throw new Error(`API error: ${response.status}`);
  }
  
  return await response.json();
}

// Function to process platform data and set cookies
async function processPlatformData(data, sendResponse) {
  try {
    const { domain, redirect, cookies } = data;
   
    // Set each cookie
    for (const cookie of cookies) {
      // await chrome.cookies.set({
        // console.log(redirect,cookie.domain)
        await chrome.cookies.set({
            url: `https://${cookie.domain || domain}${cookie.path || "/"}`,
            name: cookie.name,
            value: cookie.value,
            domain: cookie.domain, // Ensure domain is properly set
            path: cookie.path || "/", // Default to root path
            secure: cookie.secure !== undefined ? cookie.secure : true, // Defaults to true for secure cookies
            httpOnly:  false, // Defaults to false for general cookies
            sameSite: cookie.sameSite || "no_restriction", // Default to "no_restriction" for compatibility
            expirationDate: Date.now() / 1000 + 86400 * 30, // Default to 30 days expiration if not provided
            session: cookie.session || false, // Defaults to false, making the cookie persistent unless specified
        });
    }
    
    // Open in a new tab
    chrome.tabs.create({ url: redirect || `https://${domain}` });
    
    // Increment the access count
    chrome.storage.local.get(['accessCount'], function(result) {
      const count = (result.accessCount || 0) + 1;
      chrome.storage.local.set({ accessCount: count });
      // console.log("Access count incremented to:", count);
    });
    
    sendResponse({ success: true });
    
  } catch (error) {
    // console.error('Error processing platform data:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Extension installation handler
chrome.runtime.onInstalled.addListener(function(details) {
  // console.log(`📦 Extension ${details.reason} - loading heartbeat state`);
  
  // Load heartbeat state on install/update
  loadHeartbeatState().then(() => {
      // Check all slots on install/update after a short delay
      setTimeout(() => {
          checkAllActiveSlots();
      }, 3000); // 3 seconds wait
  });
  
  // ✅ FIXED: Improved script injection with comprehensive error handling
  chrome.tabs.query({}, (tabs) => {
      for (const tab of tabs) {
        // Skip if no URL
        if (!tab.url) {
          continue;
        }
        
        // Comprehensive list of restricted URL patterns
        const restrictedPatterns = [
          "chrome://",
          "edge://",
          "about:",
          "chrome-extension://",
          "moz-extension://",
          "chrome.google.com/webstore",
          "chromewebstore.google.com"
        ];
        
        // Check if URL is restricted
        const isRestricted = restrictedPatterns.some(pattern => 
          tab.url.startsWith(pattern) || tab.url.includes(pattern)
        );
        
        if (isRestricted) {
          // console.debug(`Skipping restricted tab: ${tab.url}`);
          continue;
        }
        
        // Only inject on HTTP/HTTPS pages (skip other protocols)
        if (!tab.url.startsWith("http://") && !tab.url.startsWith("https://")) {
          // console.debug(`Skipping non-HTTP(S) tab: ${tab.url}`);
          continue;
        }
        
        // ✅ FIXED: Inject script with proper error handling
        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["content.js"],
        }).catch((error) => {
            // Handle permission errors gracefully
            // Don't log as error if it's a known restriction (expected behavior)
            if (error.message && error.message.includes("Cannot access contents")) {
                // This is expected for some restricted pages - silently skip
                // console.debug(`Cannot inject script in tab ${tab.id}: ${error.message}`);
            } else {
                // Log other unexpected errors for debugging
                // console.warn(`Failed to inject script in tab ${tab.id} (${tab.url}):`, error.message);
            }
        });
      }
  });
  
  if (details.reason === "install") {
    // console.log("Extension installed! Opening welcome page");
    chrome.tabs.create({
      url: "welcome.html"
    });
  } else if (details.reason === "update") {
    // console.log("Extension updated");
  }
});

// Add browser action click handler
chrome.action.onClicked.addListener(function(tab) {
  // console.log("Extension icon clicked");
  chrome.tabs.sendMessage(tab.id, { type: "EXTENSION_ACTIVATED" });
});

// Load heartbeat state when script loads
// console.log("📱 Background script loaded");
loadHeartbeatState();