document.addEventListener('DOMContentLoaded', function() {
  // Display the extension status
  const statusElement = document.getElementById('status');
  if (statusElement) {
    statusElement.textContent = 'Extension Active';
    statusElement.className = 'status-active';
  }

  // Add event listener for the open website button
  const openWebsiteButton = document.getElementById('open-website');
  if (openWebsiteButton) {
    openWebsiteButton.addEventListener('click', function() {
      // ✅ FIXED: Use production URL with localhost fallback for development
      // For production, change to: 'https://mastertoolsbd.com'
      // For local development, change to: 'http://localhost:8080'
      const websiteUrl = 'https://mastertoolsbd.com'; // Production URL
      // const websiteUrl = 'http://localhost:8080'; // Uncomment for local development
      chrome.tabs.create({ url: websiteUrl });
    });
  }

  // Show how many cookies have been set with the extension
  chrome.storage.local.get(['cookieCount'], function(result) {
    const countElement = document.getElementById('cookie-count');
    if (countElement) {
      const count = result.cookieCount || 0;
      countElement.textContent = `${count} platforms accessed`;
    }
  });
});

// Function to update the cookie count when cookies are set
function incrementCookieCount() {
  chrome.storage.local.get(['cookieCount'], function(result) {
    const count = (result.cookieCount || 0) + 1;
    chrome.storage.local.set({ cookieCount: count });
  });
}
